package com.practice.SpringSecurity.Exception;

public class UserAlreadyRegistered extends Exception {
}
