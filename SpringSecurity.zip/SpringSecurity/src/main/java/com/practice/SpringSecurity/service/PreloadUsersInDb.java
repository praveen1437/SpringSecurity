package com.practice.SpringSecurity.service;

public interface PreloadUsersInDb {
}
