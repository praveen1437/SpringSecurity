package com.practice.SpringSecurity.service;

public interface UserDetailsService extends org.springframework.security.core.userdetails.UserDetailsService {

}
